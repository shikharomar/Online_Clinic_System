Overview: 
Our Project/website is a online-system where a patient can fix up an appointment witha Doctor over the network, record his/her ailments and 
choose a Specialized Doctor depending on his/her ailments or health complaints.


PATIENT:
1.The customer can sign up for membership with "Online Clinic".
2.The customer can Create/view his/her ailment details.
3.The customer can modify his/her ailment details.
4.The customer can view appointment details of a particular doctor on a particular date.
5.The customer can view doctor list based on specialization and date.
6.The customer can request for an appointment with an available doctor.


ADMIN:
1.The admin can add doctor details.
2.The admin can delete doctor details.
3.The admin can view doctor details.
4.The admin can modify doctor details.
5.The admin can suggest patient with an alternate doctor (in case the previous doctor is unavailable after fixing an appointment)
6.The admin can see the list of patients fixed for appointments on selected Date.
7.The admin can see the availability of doctors on a givendate.
8.The admin can see about the doctors who are on leave after fixing the appointment.